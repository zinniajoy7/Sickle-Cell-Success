# Sickle Cell Success

An interactive website that explains sickle cell disease and guides patients, caregivers, clinicians, and community members to concrete steps that help more people with sickle cell use Medicare to get their pain medications — raising that share from **12.4% to 15.9%**.

## What's inside

- **Home** — the goal at a glance (an interactive 100-dot visualization), a three-step journey, and quick entry points by role.
- **Understand sickle cell** (`/learn`) — an animated blood-vessel explorer comparing healthy and sickled cells, key facts, an inheritance calculator, common questions, and a myth-or-fact quiz.
- **Your action plan** (`/act`) — tailored checklists for patients, caregivers, clinicians/pharmacists, and community members, covering Part D enrollment, Extra Help, written pain plans, the sickle cell exemption at the pharmacy, and more. Progress is saved privately in the browser and the plan can be printed.
- **Take the pledge** (`/pledge`) — a short form where visitors commit to one action this month, collected with Netlify Forms.

## Technology

TanStack Start (React 19), Tailwind CSS 4, shadcn/ui components, Netlify Forms, and Netlify Image CDN. Deployed on Netlify.

## Run locally

```bash
pnpm install
netlify dev        # or: pnpm dev
```

Netlify Forms submissions only work on a deployed site; locally the pledge form shows its error state.

## Editing content

All copy — the goal figures, checklists, myths, and resource links — lives in `src/content/site.ts`.

## Ideas for what's next

- A public pledge counter by ZIP code or state
- Spanish-language version
- Printable QR flyer for churches, barbershops, and clinics
- Optional reminder emails for pledge-takers who opt in
