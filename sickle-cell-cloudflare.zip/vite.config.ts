import { defineConfig } from 'vite'
import { tanstackStart } from '@tanstack/react-start/plugin/vite'
import viteReact from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

const config = defineConfig({
  resolve: { tsconfigPaths: true },
  plugins: [
    tailwindcss(),
    // Pre-builds each page to plain HTML so any static host (Cloudflare Pages) can serve it.
    tanstackStart({
      prerender: { enabled: true, crawlLinks: true },
      pages: [{ path: '/' }, { path: '/learn' }, { path: '/act' }, { path: '/pledge' }],
    }),
    viteReact(),
  ],
})

export default config
