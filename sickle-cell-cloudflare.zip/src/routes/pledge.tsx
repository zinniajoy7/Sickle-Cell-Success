import { useState, type FormEvent } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { CircleCheck, HandHeart } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { roles } from '@/content/site'

export const Route = createFileRoute('/pledge')({
  head: () => ({
    meta: [
      { title: 'Take the pledge — Sickle Cell Success' },
      {
        name: 'description',
        content:
          'Commit to one concrete action this month to help people with sickle cell disease use Medicare to get pain medication.',
      },
    ],
  }),
  component: Pledge,
})

const commitments = [
  'Check my (or a loved one’s) Medicare drug coverage during Open Enrollment',
  'Apply for Extra Help, or help someone else apply',
  'Get a written pain plan from my care team',
  'Share this site with three people',
  'Host or attend a Medicare help session in my community',
  'Add the sickle cell diagnosis code to every pain prescription I write',
]

// Where pledges are sent. On Cloudflare Pages, replace this with a form service URL
// (for example a Formspree link like https://formspree.io/f/xxxxxxxx).
const PLEDGE_ENDPOINT = '/pledge-form.html'

type State = 'idle' | 'pending' | 'success' | 'error'

function Pledge() {
  const [state, setState] = useState<State>('idle')
  const [commitment, setCommitment] = useState('')

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (state === 'pending') return
    const body = new URLSearchParams()
    new FormData(event.currentTarget).forEach((value, key) => body.append(key, String(value)))
    setState('pending')
    try {
      const response = await fetch(PLEDGE_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
        signal: AbortSignal.timeout(15000),
      })
      if (!response.ok) throw new Error('Submission failed')
      const isUnprocessedRegistration = /\bdata-netlify\s*=/i.test(await response.text())
      if (isUnprocessedRegistration) throw new Error('Form handling is unavailable')
      setState('success')
    } catch {
      setState('error')
    }
  }

  return (
    <div className="mx-auto grid max-w-content gap-12 px-4 pt-14 sm:px-6 lg:grid-cols-[1fr_1.3fr]">
      <header className="rise space-y-5 lg:sticky lg:top-28 lg:self-start">
        <span className="grid size-14 place-items-center rounded-2xl bg-primary text-primary-foreground">
          <HandHeart className="size-7" aria-hidden="true" />
        </span>
        <p className="text-sm font-bold tracking-[0.18em] text-primary uppercase">Community pledge</p>
        <h1 className="font-display text-5xl leading-[1.05] font-semibold tracking-tight text-balance">
          Pick one thing. Do it this month.
        </h1>
        <p className="text-lg text-muted-foreground">
          Moving from 12.4% to 15.9% won’t happen through one big program — it happens when
          patients, families, clinicians, and neighbors each take one specific step. Tell us yours.
        </p>
        <p className="text-sm text-muted-foreground">
          We only use your details to count pledges by community and, if you ask, to send occasional
          reminders. We never sell or share them.
        </p>
      </header>

      {state === 'success' ? (
        <div className="rise flex flex-col items-start gap-5 rounded-[2rem] bg-primary p-8 text-primary-foreground sm:p-10" role="status">
          <CircleCheck className="size-12 text-accent" aria-hidden="true" />
          <h2 className="font-display text-4xl font-semibold">Your pledge is in.</h2>
          <p className="text-lg text-primary-foreground/85">
            You committed to: <strong className="text-primary-foreground">{commitment}</strong>. Thank
            you for helping someone get the relief they need.
          </p>
          <Button variant="secondary" className="rounded-full" onClick={() => setState('idle')}>
            Make another pledge
          </Button>
        </div>
      ) : (
        <form
          name="pledge"
          method="POST"
          action="/pledge-form.html"
          data-netlify="true"
          netlify-honeypot="bot-field"
          onSubmit={submit}
          onChange={() => {
            if (state === 'error') setState('idle')
          }}
          className="rounded-[2rem] border border-border bg-card p-6 sm:p-10"
        >
          <input type="hidden" name="form-name" value="pledge" />
          <p hidden>
            <label>
              Leave empty
              <input name="bot-field" tabIndex={-1} autoComplete="off" />
            </label>
          </p>
          <fieldset disabled={state === 'pending'} className="space-y-8">
            <fieldset className="space-y-3">
              <legend className="mb-3 font-display text-xl font-semibold">I pledge to…</legend>
              {commitments.map((c) => (
                <label
                  key={c}
                  className={cn(
                    'flex cursor-pointer items-start gap-3 rounded-2xl border-2 px-4 py-3.5 transition-colors has-[:focus-visible]:ring-[3px] has-[:focus-visible]:ring-ring/50 motion-reduce:transition-none',
                    commitment === c ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40',
                  )}
                >
                  <input
                    type="radio"
                    name="commitment"
                    value={c}
                    required
                    checked={commitment === c}
                    onChange={() => setCommitment(c)}
                    className="mt-1 size-4 shrink-0 accent-[var(--primary)]"
                  />
                  <span>{c}</span>
                </label>
              ))}
            </fieldset>

            <div className="grid gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="name">First name or initials</Label>
                <Input id="name" name="name" autoComplete="given-name" maxLength={60} className="h-11" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="zip">ZIP code</Label>
                <Input
                  id="zip"
                  name="zip"
                  inputMode="numeric"
                  autoComplete="postal-code"
                  pattern="[0-9]{5}"
                  title="Five-digit ZIP code"
                  required
                  className="h-11"
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="role">I am…</Label>
                <select
                  id="role"
                  name="role"
                  required
                  defaultValue=""
                  className="h-11 w-full rounded-md border border-input bg-transparent px-3 text-base shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
                >
                  <option value="" disabled>
                    Choose one
                  </option>
                  {roles.map((r) => (
                    <option key={r.id} value={r.short}>
                      {r.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="email">Email (optional)</Label>
                <Input id="email" name="email" type="email" autoComplete="email" maxLength={254} className="h-11" />
              </div>
            </div>

            <label className="flex items-start gap-3 text-sm">
              <input type="checkbox" name="updates" value="yes" className="mt-0.5 size-4 accent-[var(--primary)]" />
              Send me a reminder about my pledge and Open Enrollment deadlines.
            </label>

            <Button type="submit" size="lg" className="h-12 w-full rounded-full text-base sm:w-auto sm:px-10">
              {state === 'pending' ? 'Saving your pledge…' : 'Add my pledge'}
            </Button>

            {state === 'error' && (
              <p role="alert" className="rounded-xl bg-destructive/10 p-4 text-sm text-destructive">
                Your pledge wasn’t confirmed as saved. Your answers are still here — please try
                again in a moment.
              </p>
            )}
          </fieldset>
        </form>
      )}
    </div>
  )
}
