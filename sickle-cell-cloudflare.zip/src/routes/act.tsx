import { useEffect, useState } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, ExternalLink, Printer, RotateCcw } from 'lucide-react'
import { z } from 'zod'

import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { cn } from '@/lib/utils'
import { resources, roles, type RoleId } from '@/content/site'

const searchSchema = z.object({
  role: z.enum(['patient', 'caregiver', 'clinician', 'community']).optional(),
})

export const Route = createFileRoute('/act')({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: 'Your action plan — Sickle Cell Success' },
      {
        name: 'description',
        content:
          'Step-by-step checklists for patients, caregivers, clinicians, and community members to help more people with sickle cell use Medicare to get pain medication.',
      },
    ],
  }),
  component: ActionPlan,
})

const STORAGE_KEY = 'scs-action-plan-v1'

function ProgressRing({ value }: { value: number }) {
  const r = 34
  const c = 2 * Math.PI * r
  return (
    <svg viewBox="0 0 80 80" className="size-20 -rotate-90" aria-hidden="true">
      <circle cx="40" cy="40" r={r} className="fill-none stroke-border" strokeWidth="8" />
      <circle
        cx="40"
        cy="40"
        r={r}
        className="fill-none stroke-primary transition-[stroke-dashoffset] duration-700 motion-reduce:transition-none"
        strokeWidth="8"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - value)}
      />
    </svg>
  )
}

function ActionPlan() {
  const { role: roleParam } = Route.useSearch()
  const navigate = Route.useNavigate()
  const roleId: RoleId = roleParam ?? 'patient'
  const role = roles.find((r) => r.id === roleId) ?? roles[0]

  const [done, setDone] = useState<Record<string, boolean>>({})
  const [loaded, setLoaded] = useState(false)

  // localStorage is browser-only; read it after hydration.
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY)
      if (saved) setDone(JSON.parse(saved) as Record<string, boolean>)
    } catch {
      // Ignore unreadable saved progress and start fresh.
    }
    setLoaded(true)
  }, [])

  useEffect(() => {
    if (loaded) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(done))
  }, [done, loaded])

  const completed = role.steps.filter((s) => done[s.id]).length
  const ratio = completed / role.steps.length

  function resetRole() {
    setDone((d) => {
      const next = { ...d }
      role.steps.forEach((s) => delete next[s.id])
      return next
    })
  }

  return (
    <div className="mx-auto max-w-content px-4 sm:px-6">
      <header className="rise space-y-4 pt-14 pb-8">
        <p className="text-sm font-bold tracking-[0.18em] text-primary uppercase">Your action plan</p>
        <h1 className="max-w-3xl font-display text-5xl leading-[1.05] font-semibold tracking-tight text-balance sm:text-6xl">
          Small steps that get medicine into hands.
        </h1>
        <p className="max-w-reading text-lg text-muted-foreground">
          Choose who you are. Check off each step as you finish it — your progress is saved on
          this device only, never sent anywhere.
        </p>
      </header>

      <div role="group" aria-label="Who are you?" className="flex flex-wrap gap-2 print:hidden">
        {roles.map((r) => (
          <button
            key={r.id}
            type="button"
            aria-pressed={r.id === roleId}
            onClick={() => navigate({ search: { role: r.id }, replace: true, resetScroll: false })}
            className={cn(
              'rounded-full border-2 px-5 py-2.5 font-bold transition-colors motion-reduce:transition-none',
              r.id === roleId
                ? 'border-primary bg-primary text-primary-foreground'
                : 'border-border bg-card hover:border-primary/50',
            )}
          >
            {r.label}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1.7fr_1fr]">
        <section aria-labelledby="steps-title" className="space-y-4">
          <div className="flex items-center gap-5 rounded-3xl bg-secondary p-6">
            <div className="relative">
              <ProgressRing value={loaded ? ratio : 0} />
              <span className="absolute inset-0 grid place-items-center font-display text-lg font-semibold tabular-nums">
                {loaded ? completed : 0}/{role.steps.length}
              </span>
            </div>
            <div className="flex-1 space-y-1">
              <h2 id="steps-title" className="font-display text-2xl font-semibold">
                {role.short} checklist
              </h2>
              <p className="text-sm text-muted-foreground">{role.intro}</p>
            </div>
          </div>

          <ol className="space-y-3">
            {role.steps.map((step, i) => {
              const checked = !!done[step.id]
              const inputId = `step-${step.id}`
              return (
                <li
                  key={step.id}
                  className={cn(
                    'rise rounded-3xl border bg-card p-5 transition-colors sm:p-6 motion-reduce:transition-none',
                    checked ? 'border-primary/40 bg-primary/[0.04]' : 'border-border',
                  )}
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <div className="flex gap-4">
                    <Checkbox
                      id={inputId}
                      checked={checked}
                      onCheckedChange={(v) => setDone((d) => ({ ...d, [step.id]: v === true }))}
                      className="mt-1 size-6 rounded-md"
                    />
                    <div className="flex-1 space-y-2">
                      <label
                        htmlFor={inputId}
                        className={cn(
                          'block cursor-pointer font-display text-xl leading-snug font-semibold',
                          checked && 'text-muted-foreground line-through decoration-primary/60',
                        )}
                      >
                        <span className="mr-2 text-primary tabular-nums">{i + 1}.</span>
                        {step.title}
                      </label>
                      <p className="text-muted-foreground">{step.detail}</p>
                      <p className="text-sm">
                        <span className="font-bold">Why it matters: </span>
                        {step.why}
                      </p>
                      {step.link && (
                        <a
                          href={step.link.href}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 text-sm font-bold text-primary hover:underline"
                        >
                          {step.link.label} <ExternalLink className="size-3.5" aria-hidden="true" />
                        </a>
                      )}
                    </div>
                  </div>
                </li>
              )
            })}
          </ol>

          {loaded && completed === role.steps.length && (
            <div className="rise rounded-3xl bg-primary p-6 text-primary-foreground" role="status">
              <p className="font-display text-2xl font-semibold">Every step done. Thank you.</p>
              <p className="mt-1 text-primary-foreground/85">
                Now help one more person: share this plan, or add your name to the community pledge.
              </p>
              <Button asChild variant="secondary" className="mt-4 rounded-full">
                <Link to="/pledge">
                  Take the pledge <ArrowRight />
                </Link>
              </Button>
            </div>
          )}

          <div className="flex flex-wrap gap-3 pt-2 print:hidden">
            <Button variant="outline" className="rounded-full" onClick={() => window.print()}>
              <Printer /> Print this plan
            </Button>
            <Button variant="ghost" className="rounded-full" onClick={resetRole} disabled={completed === 0}>
              <RotateCcw /> Clear checks
            </Button>
          </div>
        </section>

        <aside aria-labelledby="help-title" className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <h2 id="help-title" className="font-display text-2xl font-semibold">
            Where to get help
          </h2>
          <ul className="divide-y divide-border rounded-3xl border border-border bg-card">
            {resources.map((r) => (
              <li key={r.name}>
                <a
                  href={r.href}
                  target={r.href.startsWith('http') ? '_blank' : undefined}
                  rel="noreferrer"
                  className="group flex items-start justify-between gap-3 p-5 transition-colors hover:bg-muted motion-reduce:transition-none"
                >
                  <span>
                    <span className="block font-bold group-hover:text-primary">{r.name}</span>
                    <span className="block text-sm text-muted-foreground">{r.detail}</span>
                  </span>
                  <ExternalLink className="mt-1 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                </a>
              </li>
            ))}
          </ul>
          <div className="rounded-3xl bg-accent/30 p-5 text-sm">
            <p className="font-bold">Tip for the pharmacy counter</p>
            <p className="mt-1 text-foreground/80">
              If a pain prescription is refused, say: “I have sickle cell disease. Can you check
              whether the Medicare sickle cell exemption applies, and give me the written notice
              of my rights?”
            </p>
          </div>
        </aside>
      </div>
    </div>
  )
}
