import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight } from 'lucide-react'

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { Button } from '@/components/ui/button'
import { CellExplorer } from '@/components/cell-explorer'
import { InheritanceCalculator } from '@/components/inheritance-calculator'
import { MythQuiz } from '@/components/myth-quiz'

export const Route = createFileRoute('/learn')({
  head: () => ({
    meta: [
      { title: 'Understand sickle cell disease — Sickle Cell Success' },
      {
        name: 'description',
        content:
          'An interactive guide to sickle cell disease: what happens in the blood, how it is inherited, pain crises, treatment, and common myths.',
      },
    ],
  }),
  component: Learn,
})

const quickFacts = [
  { value: '~100,000', label: 'people in the U.S. live with sickle cell disease' },
  { value: '1 in 13', label: 'Black or African American babies is born with sickle cell trait' },
  { value: '10–20 days', label: 'lifespan of a sickle cell, versus about 120 for a healthy one' },
]

const topics = [
  {
    q: 'What is a pain crisis?',
    a: 'A pain crisis (also called a vaso-occlusive crisis) happens when sickled cells block blood flow. Pain can strike the chest, back, belly, arms, or legs and may last hours to days. Triggers include cold, dehydration, stress, infection, and high altitude — but crises can also come without warning. Pain medication, fluids, and rest are core treatments, and severe crises need emergency care.',
  },
  {
    q: 'What other problems can sickle cell cause?',
    a: 'Anemia and fatigue, serious infections, acute chest syndrome (a lung emergency), stroke, vision problems, kidney damage, and damage to joints such as the hips. Regular care with a sickle cell specialist helps catch these early.',
  },
  {
    q: 'How is sickle cell treated?',
    a: 'Daily medicines such as hydroxyurea and L-glutamine can reduce crises. Blood transfusions help prevent stroke and treat severe anemia. Stem cell transplant and newer gene therapies can be curative for some people. Pain management — at home and in the hospital — is a key part of care at every stage.',
  },
  {
    q: 'Why does Medicare matter for sickle cell?',
    a: 'Many adults with sickle cell qualify for Medicare through Social Security Disability, and many older adults are now living longer with the disease. Medicare Part D covers the prescriptions picked up at the pharmacy — including pain medications — but only if a person is enrolled and can use the benefit.',
  },
  {
    q: 'Is sickle cell trait the same as the disease?',
    a: 'No. People with trait have one sickle gene and usually have no symptoms, but they can pass the gene to their children. If both parents have trait, each child has a 1 in 4 chance of being born with sickle cell disease.',
  },
]

function Learn() {
  return (
    <div className="mx-auto max-w-content px-4 sm:px-6">
      <header className="rise grid gap-6 pt-14 pb-10 lg:grid-cols-[1.3fr_1fr] lg:items-end">
        <div className="space-y-4">
          <p className="text-sm font-bold tracking-[0.18em] text-primary uppercase">Understand</p>
          <h1 className="font-display text-5xl leading-[1.05] font-semibold tracking-tight text-balance sm:text-6xl">
            What is sickle cell disease?
          </h1>
        </div>
        <p className="text-lg text-muted-foreground">
          Sickle cell disease is an inherited blood disorder. It changes the shape of red blood
          cells — and that one change explains the pain, the tiredness, and why steady access to
          medication matters so much.
        </p>
      </header>

      <section aria-labelledby="explore" className="space-y-5">
        <h2 id="explore" className="font-display text-3xl font-semibold">
          See what happens inside a blood vessel
        </h2>
        <CellExplorer />
      </section>

      <section aria-label="Quick facts" className="mt-14 grid gap-4 sm:grid-cols-3">
        {quickFacts.map((f, i) => (
          <div
            key={f.label}
            className={i === 1 ? 'rounded-3xl bg-primary p-6 text-primary-foreground' : 'rounded-3xl bg-secondary p-6'}
          >
            <p className="font-display text-4xl font-semibold">{f.value}</p>
            <p className={i === 1 ? 'mt-2 text-primary-foreground/85' : 'mt-2 text-muted-foreground'}>{f.label}</p>
          </div>
        ))}
      </section>

      <section aria-labelledby="inherit" className="mt-20 space-y-5">
        <div className="max-w-reading space-y-2">
          <h2 id="inherit" className="font-display text-3xl font-semibold">
            How is it passed down?
          </h2>
          <p className="text-muted-foreground">
            Everyone gets one hemoglobin gene from each parent. Pick each parent’s status to see the
            chances for a child.
          </p>
        </div>
        <InheritanceCalculator />
      </section>

      <section aria-labelledby="topics" className="mt-20 grid gap-10 lg:grid-cols-[1fr_1.6fr]">
        <div className="space-y-3">
          <h2 id="topics" className="font-display text-3xl font-semibold">
            Common questions
          </h2>
          <p className="text-muted-foreground">
            Short answers to what patients and families ask most often.
          </p>
        </div>
        <Accordion type="single" collapsible defaultValue="item-0" className="rounded-3xl border border-border bg-card px-6">
          {topics.map((t, i) => (
            <AccordionItem key={t.q} value={`item-${i}`}>
              <AccordionTrigger className="py-5 font-display text-lg font-semibold">{t.q}</AccordionTrigger>
              <AccordionContent className="text-base text-muted-foreground">{t.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      <section aria-label="Myth or fact quiz" className="mt-20">
        <MythQuiz />
      </section>

      <section className="mt-16 flex flex-col items-start justify-between gap-6 rounded-[2rem] border-2 border-dashed border-primary/40 p-8 sm:flex-row sm:items-center">
        <div>
          <h2 className="font-display text-2xl font-semibold">Ready to turn knowledge into action?</h2>
          <p className="text-muted-foreground">Get a personal checklist for using Medicare to get pain relief.</p>
        </div>
        <Button asChild size="lg" className="h-12 rounded-full px-7 text-base">
          <Link to="/act">
            Build my action plan <ArrowRight />
          </Link>
        </Button>
      </section>
    </div>
  )
}
