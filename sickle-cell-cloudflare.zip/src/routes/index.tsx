import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, BookOpen, ClipboardCheck, HandHeart, Pill } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { GoalMeter } from '@/components/goal-meter'
import { roles } from '@/content/site'

export const Route = createFileRoute('/')({
  component: Home,
})

const img = (file: string, w: number) => `/img/${file}`

const journey = [
  {
    icon: BookOpen,
    title: 'Understand',
    text: 'See what happens inside the blood, why pain crises happen, and how sickle cell is inherited.',
    to: '/learn',
  },
  {
    icon: ClipboardCheck,
    title: 'Make your plan',
    text: 'Pick your role and get a step-by-step checklist that saves your progress on this device.',
    to: '/act',
  },
  {
    icon: HandHeart,
    title: 'Commit',
    text: 'Choose one thing you will do this month and add your name to the community pledge.',
    to: '/pledge',
  },
] as const

function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-content items-center gap-10 px-4 pt-12 pb-16 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:pt-20">
          <div className="rise space-y-7">
            <p className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-sm font-bold text-secondary-foreground">
              <Pill className="size-4" aria-hidden="true" /> Medicare Open Enrollment runs Oct 15 – Dec 7
            </p>
            <h1 className="font-display text-5xl leading-[1.02] font-semibold tracking-tight text-balance sm:text-6xl lg:text-7xl">
              Sickle cell pain is real.{' '}
              <em className="font-normal text-primary">So is your coverage.</em>
            </h1>
            <p className="max-w-reading text-lg text-muted-foreground sm:text-xl">
              Learn how sickle cell disease works, then take simple, specific steps — as a patient,
              caregiver, clinician, or neighbor — so more people use Medicare to get the pain
              medication they need.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg" className="h-12 rounded-full px-7 text-base">
                <Link to="/act">
                  Build my action plan <ArrowRight />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-7 text-base">
                <Link to="/learn">What is sickle cell?</Link>
              </Button>
            </div>
          </div>
          <div className="rise relative [animation-delay:150ms]">
            <div className="absolute -top-6 -right-10 hidden size-40 rounded-full bg-accent/30 blur-2xl lg:block" />
            <img
              src={img('hero.png', 1200)}
              srcSet={`${img('hero.png', 640)} 640w, ${img('hero.png', 1200)} 1200w`}
              sizes="(min-width: 1024px) 560px, 100vw"
              width={1264}
              height={848}
              alt="Illustration of a grandmother, mother, and teenage son sitting together on a porch; the son holds a pill organizer and a phone."
              className="relative w-full rotate-1 rounded-[2rem] border-4 border-card shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Goal */}
      <section className="mx-auto grid max-w-content gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_1.15fr] lg:items-center">
        <div className="space-y-5">
          <h2 className="font-display text-4xl leading-tight font-semibold text-balance">
            From 12.4% to 15.9% — one prescription at a time.
          </h2>
          <p className="text-lg text-muted-foreground">
            Many people with sickle cell disease already have Medicare, but don’t have drug
            coverage, can’t afford the copay, or get turned away at the pharmacy counter. Each of
            those gaps has a fix — and most fixes take less than an afternoon.
          </p>
          <ul className="space-y-3 text-base">
            {[
              'Add Part D drug coverage and check that pain medicines are on the list',
              'Apply for Extra Help to cut drug costs',
              'Carry a written pain plan and know the sickle cell exemption at the pharmacy',
            ].map((t) => (
              <li key={t} className="flex gap-3">
                <span className="mt-2 size-2.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                {t}
              </li>
            ))}
          </ul>
        </div>
        <GoalMeter />
      </section>

      {/* Journey */}
      <section className="mx-auto max-w-content px-4 py-16 sm:px-6">
        <h2 className="font-display text-3xl font-semibold">Three steps to make a difference</h2>
        <ol className="mt-8 grid gap-5 md:grid-cols-3">
          {journey.map((step, i) => (
            <li key={step.title} className={i === 1 ? 'md:translate-y-8' : i === 2 ? 'md:translate-y-16' : ''}>
              <Link
                to={step.to}
                className="group flex h-full flex-col gap-4 rounded-3xl border border-border bg-card p-7 transition-[transform,box-shadow] hover:-translate-y-1 hover:shadow-xl motion-reduce:transition-none"
              >
                <span className="flex items-center justify-between">
                  <span className="grid size-12 place-items-center rounded-2xl bg-primary text-primary-foreground">
                    <step.icon aria-hidden="true" />
                  </span>
                  <span className="font-display text-5xl font-semibold text-border">0{i + 1}</span>
                </span>
                <span className="font-display text-2xl font-semibold">{step.title}</span>
                <span className="text-muted-foreground">{step.text}</span>
                <span className="mt-auto inline-flex items-center gap-1 font-bold text-primary">
                  Start <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
            </li>
          ))}
        </ol>
      </section>

      {/* Roles */}
      <section className="mt-16 bg-primary text-primary-foreground">
        <div className="mx-auto grid max-w-content gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1fr] lg:items-center">
          <img
            src={img('community.png', 800)}
            width={1024}
            height={1024}
            loading="lazy"
            alt="Illustration of a community health worker helping an older man with his Medicare card and paperwork at a kitchen table, with a pharmacist shown in an inset."
            className="w-full max-w-md -rotate-2 rounded-[2rem] border-4 border-primary-foreground/20 shadow-2xl justify-self-center"
          />
          <div className="space-y-6">
            <h2 className="font-display text-4xl font-semibold text-balance">
              Everyone has a part to play.
            </h2>
            <p className="text-lg text-primary-foreground/80">
              Choose who you are and we’ll show you the steps that matter most for you.
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              {roles.map((role) => (
                <Link
                  key={role.id}
                  to="/act"
                  search={{ role: role.id }}
                  className="flex items-center justify-between rounded-2xl bg-primary-foreground/10 px-5 py-4 font-bold transition-colors hover:bg-primary-foreground hover:text-primary motion-reduce:transition-none"
                >
                  {role.label}
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
