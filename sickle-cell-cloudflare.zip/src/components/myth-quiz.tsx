import { useState } from 'react'
import { Check, RotateCcw, X } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'
import { myths } from '@/content/site'

export function MythQuiz() {
  const [index, setIndex] = useState(0)
  const [answer, setAnswer] = useState<boolean | null>(null)
  const [score, setScore] = useState(0)

  const done = index >= myths.length
  const item = myths[Math.min(index, myths.length - 1)]

  function choose(value: boolean) {
    if (answer !== null) return
    setAnswer(value)
    if (value === item.truth) setScore((s) => s + 1)
  }

  function next() {
    setAnswer(null)
    setIndex((i) => i + 1)
  }

  function restart() {
    setIndex(0)
    setAnswer(null)
    setScore(0)
  }

  return (
    <div className="rounded-[2rem] bg-foreground p-6 text-background sm:p-10">
      <div className="mb-6 flex items-center justify-between gap-4 text-sm">
        <span className="font-bold tracking-[0.18em] text-accent uppercase">Myth or fact?</span>
        <span className="tabular-nums text-background/70">
          {done ? myths.length : index + 1} / {myths.length}
        </span>
      </div>
      <Progress
        value={((done ? myths.length : index) / myths.length) * 100}
        className="mb-8 h-1.5 bg-background/15 [&>*]:bg-accent"
        aria-label="Quiz progress"
      />

      {done ? (
        <div className="space-y-5" aria-live="polite">
          <p className="font-display text-4xl font-semibold">
            You got {score} of {myths.length}.
          </p>
          <p className="max-w-reading text-background/75">
            {score === myths.length
              ? 'Perfect score. Share what you know — misinformation is one of the biggest barriers to care.'
              : 'Every myth you can correct in a conversation helps someone get treated with respect.'}
          </p>
          <Button variant="secondary" onClick={restart} className="rounded-full">
            <RotateCcw /> Try again
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          <p className="font-display text-3xl leading-snug font-semibold text-balance sm:text-4xl">
            “{item.statement}”
          </p>
          <div className="flex flex-wrap gap-3">
            {[
              { v: true, label: 'Fact' },
              { v: false, label: 'Myth' },
            ].map(({ v, label }) => {
              const picked = answer === v
              const correct = answer !== null && v === item.truth
              return (
                <button
                  key={label}
                  type="button"
                  onClick={() => choose(v)}
                  disabled={answer !== null}
                  className={cn(
                    'min-w-32 rounded-full border-2 px-6 py-3 text-lg font-bold transition-colors focus-visible:ring-[3px] focus-visible:ring-accent/60 focus-visible:outline-none motion-reduce:transition-none',
                    answer === null && 'border-background/30 hover:border-accent hover:text-accent',
                    correct && 'border-accent bg-accent text-accent-foreground',
                    picked && !correct && 'border-destructive bg-destructive text-destructive-foreground',
                    answer !== null && !picked && !correct && 'border-background/15 text-background/40',
                  )}
                >
                  {label}
                </button>
              )
            })}
          </div>
          {answer !== null && (
            <div className="rise space-y-4" aria-live="polite">
              <p className="flex items-center gap-2 font-bold">
                {answer === item.truth ? (
                  <>
                    <Check className="text-accent" aria-hidden="true" /> Correct — it’s a {item.truth ? 'fact' : 'myth'}.
                  </>
                ) : (
                  <>
                    <X className="text-destructive-foreground" aria-hidden="true" /> Not quite — it’s a{' '}
                    {item.truth ? 'fact' : 'myth'}.
                  </>
                )}
              </p>
              <p className="max-w-reading text-background/80">{item.explain}</p>
              <Button onClick={next} variant="secondary" className="rounded-full">
                {index === myths.length - 1 ? 'See my score' : 'Next question'}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
