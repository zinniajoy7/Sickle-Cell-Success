import { useEffect, useState } from 'react'

import { cn } from '@/lib/utils'

type Mode = 'healthy' | 'sickle'

const lanes = [52, 80, 108]
const cells = Array.from({ length: 12 }, (_, i) => ({
  lane: lanes[i % 3],
  delay: (i * 0.55) % 6,
  tilt: (i * 37) % 60 - 30,
}))

const stuck = [
  { x: 392, y: 70, r: 20 },
  { x: 410, y: 92, r: -35 },
  { x: 380, y: 98, r: 60 },
  { x: 418, y: 66, r: 110 },
  { x: 400, y: 80, r: 160 },
]

function HealthyCell() {
  return (
    <g>
      <ellipse rx="15" ry="13" className="fill-primary" />
      <ellipse rx="7" ry="5.5" className="fill-[oklch(0.36_0.13_24)]" />
    </g>
  )
}

function SickleCell() {
  return <path d="M-16 4C-10-12 10-12 16 4 8-4-8-4-16 4Z" className="fill-[oklch(0.5_0.16_30)]" />
}

const copy: Record<Mode, { title: string; points: string[] }> = {
  healthy: {
    title: 'Healthy red blood cells',
    points: [
      'Round, flexible discs that bend to squeeze through tiny blood vessels.',
      'Carry oxygen from the lungs to every part of the body.',
      'Live about 120 days before the body replaces them.',
    ],
  },
  sickle: {
    title: 'Sickle-shaped red blood cells',
    points: [
      'An inherited change in hemoglobin makes cells stiff, sticky, and curved like a farm tool called a sickle.',
      'They clump together and block blood flow — starving tissue of oxygen and causing sudden, severe pain called a pain crisis.',
      'They die in only 10 to 20 days, so the body is often short on red cells (anemia), causing tiredness.',
    ],
  },
}

export function CellExplorer() {
  const [mode, setMode] = useState<Mode>('sickle')
  const [animate, setAnimate] = useState(false)

  // SVG SMIL animation ignores the CSS reduced-motion query, so check it here.
  useEffect(() => {
    setAnimate(!window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  }, [])

  const isSickle = mode === 'sickle'

  return (
    <div className="grid gap-8 rounded-[2rem] border border-border bg-card p-6 sm:p-8 lg:grid-cols-[1.4fr_1fr] lg:items-center">
      <div>
        <div role="group" aria-label="Choose cell type" className="mb-5 inline-flex rounded-full bg-muted p-1 text-sm">
          {(['healthy', 'sickle'] as const).map((m) => (
            <button
              key={m}
              type="button"
              aria-pressed={mode === m}
              onClick={() => setMode(m)}
              className={cn(
                'rounded-full px-5 py-2 font-bold transition-colors motion-reduce:transition-none',
                mode === m ? 'bg-primary text-primary-foreground' : 'text-muted-foreground',
              )}
            >
              {m === 'healthy' ? 'Healthy blood' : 'Sickle cell disease'}
            </button>
          ))}
        </div>
        <svg
          viewBox="0 0 600 160"
          className="w-full overflow-visible"
          role="img"
          aria-label={
            isSickle
              ? 'Animation: crescent-shaped cells pile up where the blood vessel narrows, blocking flow.'
              : 'Animation: round red blood cells flow smoothly through a blood vessel.'
          }
        >
          <defs>
            <clipPath id="vessel">
              <path d={isSickle ? 'M0 30H340Q400 30 420 55H600V105H420Q400 130 340 130H0Z' : 'M0 30H600V130H0Z'} />
            </clipPath>
          </defs>
          <path
            d={isSickle ? 'M0 30H340Q400 30 420 55H600V105H420Q400 130 340 130H0Z' : 'M0 30H600V130H0Z'}
            className="fill-[oklch(0.93_0.04_40)] stroke-[oklch(0.75_0.08_30)]"
            strokeWidth="3"
          />
          <g clipPath="url(#vessel)">
            {cells.map((c, i) => (
              <g key={`${mode}-${i}`} transform={`translate(${-40 + i * 52} ${c.lane})`}>
                {animate && (
                  <animateTransform
                    attributeName="transform"
                    type="translate"
                    values={isSickle ? `-40 ${c.lane}; 360 ${c.lane}` : `-40 ${c.lane}; 640 ${c.lane}`}
                    dur={isSickle ? '7s' : '4.5s'}
                    begin={`${-c.delay}s`}
                    repeatCount="indefinite"
                  />
                )}
                <g transform={`rotate(${c.tilt})`}>{isSickle ? <SickleCell /> : <HealthyCell />}</g>
              </g>
            ))}
            {isSickle &&
              stuck.map((s, i) => (
                <g key={i} transform={`translate(${s.x} ${s.y}) rotate(${s.r})`}>
                  <SickleCell />
                </g>
              ))}
          </g>
          {isSickle && (
            <g transform="translate(470 80)">
              <circle r="14" className="fill-accent/40">
                {animate && <animate attributeName="r" values="12;22;12" dur="1.6s" repeatCount="indefinite" />}
              </circle>
              <text y="-30" textAnchor="middle" className="fill-foreground text-[13px] font-bold">
                Blocked flow = pain
              </text>
            </g>
          )}
        </svg>
      </div>
      <div aria-live="polite" className="space-y-4">
        <h3 className="font-display text-2xl font-semibold">{copy[mode].title}</h3>
        <ul className="space-y-3">
          {copy[mode].points.map((p) => (
            <li key={p} className="flex gap-3 text-muted-foreground">
              <span className="mt-2 size-2 shrink-0 rounded-full bg-primary" aria-hidden="true" />
              {p}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
