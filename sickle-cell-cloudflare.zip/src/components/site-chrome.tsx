import { Link } from '@tanstack/react-router'
import { Menu, Phone, TriangleAlert } from 'lucide-react'

import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { crisisNote } from '@/content/site'

const nav = [
  { to: '/learn', label: 'Understand sickle cell' },
  { to: '/act', label: 'Your action plan' },
  { to: '/pledge', label: 'Take the pledge' },
] as const

export function Logo() {
  return (
    <svg viewBox="0 0 40 40" aria-hidden="true" className="size-9 shrink-0">
      <circle cx="20" cy="20" r="17" className="fill-primary" />
      <circle cx="20" cy="20" r="7.5" className="fill-primary-foreground/25" />
      <path
        d="M9 27c7-1 15-6 19-15 1.5 4 .5 11-4 15.5-4.2 4.1-10.5 3.7-15-.5Z"
        className="fill-accent"
      />
    </svg>
  )
}

export function SiteHeader() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <div className="bg-foreground text-background">
        <p className="mx-auto flex max-w-content items-center gap-2 px-4 py-2 text-xs sm:px-6 sm:text-sm">
          <TriangleAlert className="size-4 shrink-0 text-accent" aria-hidden="true" />
          <span>{crisisNote}</span>
        </p>
      </div>
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-content items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5 rounded-md">
            <Logo />
            <span className="leading-tight">
              <span className="block font-display text-lg font-semibold tracking-tight">
                Sickle Cell Success
              </span>
              <span className="block text-xs text-muted-foreground">
                Learn · Act · Get relief
              </span>
            </span>
          </Link>
          <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="rounded-full px-4 py-2 text-sm font-bold text-foreground/80 transition-colors hover:bg-secondary hover:text-foreground motion-reduce:transition-none"
                activeProps={{ className: 'bg-secondary text-primary' }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden" aria-label="Open menu">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-background">
              <SheetHeader>
                <SheetTitle className="font-display">Sickle Cell Success</SheetTitle>
                <SheetDescription>Learn, make a plan, and help your community.</SheetDescription>
              </SheetHeader>
              <nav aria-label="Mobile" className="flex flex-col gap-1 px-4">
                {nav.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    className="rounded-lg px-3 py-3 text-base font-bold hover:bg-secondary"
                    activeProps={{ className: 'bg-secondary text-primary' }}
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </header>
    </>
  )
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border bg-secondary/60">
      <div className="mx-auto grid max-w-content gap-10 px-4 py-14 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div className="space-y-3">
          <div className="flex items-center gap-2.5">
            <Logo />
            <span className="font-display text-lg font-semibold">Sickle Cell Success</span>
          </div>
          <p className="max-w-sm text-sm text-muted-foreground">
            Education and practical steps to help more people with sickle cell disease use Medicare
            to get the pain medication they need.
          </p>
        </div>
        <div className="space-y-2 text-sm">
          <h2 className="font-display text-base font-semibold">Need Medicare help now?</h2>
          <a href="tel:18006334227" className="flex items-center gap-2 font-bold text-primary hover:underline">
            <Phone className="size-4" aria-hidden="true" /> 1-800-MEDICARE (633-4227)
          </a>
          <a href="https://www.shiphelp.org" className="block hover:underline" target="_blank" rel="noreferrer">
            Free local counseling (SHIP)
          </a>
        </div>
        <div className="space-y-2 text-sm">
          <h2 className="font-display text-base font-semibold">Explore</h2>
          {nav.map((item) => (
            <Link key={item.to} to={item.to} className="block hover:underline">
              {item.label}
            </Link>
          ))}
        </div>
      </div>
      <p className="mx-auto max-w-content px-4 pb-10 text-xs text-muted-foreground sm:px-6">
        This site is for education only and is not medical or legal advice. Talk with your health
        care team about your treatment, and confirm coverage details with your plan or Medicare.
      </p>
    </footer>
  )
}
