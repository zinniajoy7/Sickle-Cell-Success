import { useState } from 'react'

import { cn } from '@/lib/utils'

type Genotype = 'AA' | 'AS' | 'SS'

const options: { value: Genotype; label: string; hint: string }[] = [
  { value: 'AA', label: 'No trait', hint: 'Two typical genes' },
  { value: 'AS', label: 'Sickle cell trait', hint: 'One sickle gene' },
  { value: 'SS', label: 'Sickle cell disease', hint: 'Two sickle genes' },
]

const outcome: Record<Genotype, { label: string; className: string }> = {
  AA: { label: 'No trait', className: 'bg-muted text-foreground' },
  AS: { label: 'Trait (carrier)', className: 'bg-accent text-accent-foreground' },
  SS: { label: 'Sickle cell disease', className: 'bg-primary text-primary-foreground' },
}

function combine(a: string, b: string): Genotype {
  return [a, b].sort().join('') as Genotype
}

function ParentPicker({
  name,
  value,
  onChange,
}: {
  name: string
  value: Genotype
  onChange: (g: Genotype) => void
}) {
  return (
    <fieldset className="space-y-2">
      <legend className="text-sm font-bold">{name}</legend>
      <div className="grid gap-2">
        {options.map((o) => (
          <label
            key={o.value}
            className={cn(
              'flex cursor-pointer items-center justify-between rounded-xl border px-4 py-3 transition-colors has-[:focus-visible]:ring-[3px] has-[:focus-visible]:ring-ring/50 motion-reduce:transition-none',
              value === o.value ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted',
            )}
          >
            <span>
              <span className="block font-bold">{o.label}</span>
              <span className="block text-xs text-muted-foreground">{o.hint}</span>
            </span>
            <input
              type="radio"
              name={name}
              value={o.value}
              checked={value === o.value}
              onChange={() => onChange(o.value)}
              className="size-4 accent-[var(--primary)]"
            />
          </label>
        ))}
      </div>
    </fieldset>
  )
}

export function InheritanceCalculator() {
  const [mom, setMom] = useState<Genotype>('AS')
  const [dad, setDad] = useState<Genotype>('AS')

  const grid = mom.split('').map((m) => dad.split('').map((d) => combine(m, d)))
  const flat = grid.flat()
  const pct = (g: Genotype) => (flat.filter((x) => x === g).length / 4) * 100

  return (
    <div className="grid gap-8 rounded-[2rem] border border-border bg-card p-6 sm:p-8 lg:grid-cols-[1fr_1fr_1.1fr]">
      <ParentPicker name="Parent 1" value={mom} onChange={setMom} />
      <ParentPicker name="Parent 2" value={dad} onChange={setDad} />
      <div className="space-y-4">
        <p className="text-sm font-bold">With each pregnancy, the chance the child has…</p>
        <div className="grid grid-cols-2 gap-2" aria-hidden="true">
          {flat.map((g, i) => (
            <div
              key={`${i}-${g}`}
              className={cn('rise grid h-16 place-items-center rounded-xl text-center text-xs font-bold', outcome[g].className)}
              style={{ animationDelay: `${i * 60}ms` }}
            >
              {outcome[g].label}
            </div>
          ))}
        </div>
        <dl className="space-y-1.5 text-sm" aria-live="polite">
          {(['SS', 'AS', 'AA'] as const).map((g) => (
            <div key={g} className="flex justify-between border-b border-border/60 pb-1.5">
              <dt>{outcome[g].label}</dt>
              <dd className="font-bold tabular-nums">{pct(g)}%</dd>
            </div>
          ))}
        </dl>
        <p className="text-xs text-muted-foreground">
          Chances are the same for every pregnancy. This simplified view covers hemoglobin S only;
          a genetic counselor can explain other types such as hemoglobin SC.
        </p>
      </div>
    </div>
  )
}
