import { useState } from 'react'

import { cn } from '@/lib/utils'
import { goal } from '@/content/site'

// 100-dot grid: each dot is one in every hundred patients. Today's share is
// solid crimson; the additional people reached at the goal are ochre.
export function GoalMeter({ className }: { className?: string }) {
  const [view, setView] = useState<'today' | 'goal'>('goal')
  const today = Math.round(goal.baseline)
  const target = Math.round(goal.target)
  const lift = ((goal.target - goal.baseline) / goal.baseline) * 100

  return (
    <figure
      className={cn(
        'rounded-[1.75rem] border border-border bg-card p-6 shadow-[0_24px_60px_-30px_oklch(0.44_0.15_24/0.45)] sm:p-8',
        className,
      )}
    >
      <figcaption className="space-y-1">
        <p className="text-xs font-bold tracking-[0.18em] text-muted-foreground uppercase">
          Our shared goal
        </p>
        <p className="font-display text-2xl leading-snug font-semibold text-balance">
          {goal.label}
        </p>
      </figcaption>

      <div className="mt-6 flex items-end gap-6">
        <div>
          <p className="text-sm text-muted-foreground">Today</p>
          <p className="font-display text-5xl font-semibold text-primary tabular-nums">
            {goal.baseline}%
          </p>
        </div>
        <svg viewBox="0 0 48 16" className="mb-4 w-12 text-muted-foreground" aria-hidden="true">
          <path d="M2 8h40m-6-6 6 6-6 6" fill="none" stroke="currentColor" strokeWidth="2" />
        </svg>
        <div>
          <p className="text-sm text-muted-foreground">Goal</p>
          <p className="font-display text-5xl font-semibold text-[oklch(0.58_0.13_65)] tabular-nums">
            {goal.target}%
          </p>
        </div>
      </div>

      <div
        role="group"
        aria-label="Choose which picture to show"
        className="mt-6 inline-flex rounded-full bg-muted p-1 text-sm"
      >
        {(['today', 'goal'] as const).map((v) => (
          <button
            key={v}
            type="button"
            aria-pressed={view === v}
            onClick={() => setView(v)}
            className={cn(
              'rounded-full px-4 py-1.5 font-bold transition-colors motion-reduce:transition-none',
              view === v ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground',
            )}
          >
            {v === 'today' ? 'Today' : 'At our goal'}
          </button>
        ))}
      </div>

      <div
        className="mt-5 grid grid-cols-20 gap-1.5 sm:gap-2"
        role="img"
        aria-label={
          view === 'today'
            ? `About ${today} out of every 100 patients today`
            : `About ${target} out of every 100 patients at our goal`
        }
      >
        {Array.from({ length: 100 }, (_, i) => {
          const isToday = i < today
          const isGain = !isToday && i < target && view === 'goal'
          return (
            <span
              key={i}
              className={cn(
                'aspect-square rounded-full transition-all duration-500 motion-reduce:transition-none',
                isToday && 'bg-primary',
                isGain && 'scale-110 bg-accent',
                !isToday && !isGain && 'bg-border/80',
              )}
              style={{ transitionDelay: isGain ? `${(i - today) * 70}ms` : undefined }}
            />
          )
        })}
      </div>

      <p className="mt-5 text-sm text-muted-foreground">
        Each dot is 1 in every 100 patients. Reaching {goal.target}% means about{' '}
        <strong className="text-foreground">{Math.round(lift)}% more people</strong> getting the
        pain relief their coverage already allows.
      </p>
    </figure>
  )
}
