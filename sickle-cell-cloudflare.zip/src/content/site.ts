// All educational copy, action steps, and resources live here so content
// owners can update wording without touching component code.

export const goal = {
  baseline: 12.4,
  target: 15.9,
  label:
    'Share of patients with sickle cell disease using Medicare to get their pain medications',
}

export const crisisNote =
  'In a pain crisis with fever over 101°F, chest pain, trouble breathing, sudden weakness, or trouble speaking — call 911 or go to the nearest emergency room now.'

export type RoleId = 'patient' | 'caregiver' | 'clinician' | 'community'

export type ActionStep = {
  id: string
  title: string
  detail: string
  why: string
  link?: { label: string; href: string }
}

export type Role = {
  id: RoleId
  label: string
  short: string
  intro: string
  steps: ActionStep[]
}

export const roles: Role[] = [
  {
    id: 'patient',
    label: 'I live with sickle cell',
    short: 'Patient',
    intro:
      'You are the expert on your own pain. These steps help you turn your Medicare coverage into medication in your hand.',
    steps: [
      {
        id: 'p-card',
        title: 'Find your Medicare card and check for Part D',
        detail:
          'Original Medicare (Parts A and B) does not cover most prescriptions you pick up at a pharmacy. You need a Part D drug plan or a Medicare Advantage plan that includes drug coverage.',
        why: 'Many people with sickle cell qualify for Medicare through disability but never add drug coverage.',
        link: { label: 'Compare plans on Medicare.gov', href: 'https://www.medicare.gov/plan-compare' },
      },
      {
        id: 'p-list',
        title: 'Check that your pain medicines are on the plan’s drug list',
        detail:
          'Every plan has a list of covered drugs (a formulary). Enter your exact medicines and doses — including hydroxyurea, folic acid, and each pain medication — when comparing plans.',
        why: 'A plan that looks cheap can cost more if your medicine is not covered.',
      },
      {
        id: 'p-extrahelp',
        title: 'Apply for Extra Help with drug costs',
        detail:
          'Extra Help lowers Part D premiums, deductibles, and copays for people with limited income and savings. If you have both Medicare and full Medicaid, you get it automatically.',
        why: 'Cost is one of the biggest reasons prescriptions go unfilled.',
        link: { label: 'Apply at SSA.gov/extrahelp', href: 'https://www.ssa.gov/extrahelp' },
      },
      {
        id: 'p-plan',
        title: 'Ask your hematologist for a written pain plan',
        detail:
          'An individualized pain plan lists your diagnosis, the medicines and doses that work for you, and what to do at home versus in the ER. Keep a copy on your phone and in your wallet.',
        why: 'A written plan helps pharmacists and ER teams act quickly and confidently.',
      },
      {
        id: 'p-exempt',
        title: 'Know your rights at the pharmacy counter',
        detail:
          'Medicare drug plan opioid safety limits generally exempt people with sickle cell disease. If a prescription is blocked, ask the pharmacist to check for the sickle cell exemption and to give you the “Medicare Prescription Drug Coverage and Your Rights” notice.',
        why: 'Many pharmacy denials can be resolved the same day once the diagnosis is on record.',
      },
      {
        id: 'p-ship',
        title: 'Book a free counseling session with SHIP',
        detail:
          'Your State Health Insurance Assistance Program offers free, unbiased one-on-one Medicare help — in person or by phone.',
        why: 'A trained counselor can find the plan that fits your medicines in about an hour.',
        link: { label: 'Find your local SHIP', href: 'https://www.shiphelp.org' },
      },
    ],
  },
  {
    id: 'caregiver',
    label: 'I care for someone',
    short: 'Caregiver',
    intro:
      'Family members and friends often carry the paperwork. A little organizing now prevents a lot of stress during a crisis.',
    steps: [
      {
        id: 'c-folder',
        title: 'Build a “crisis folder”',
        detail:
          'Gather the Medicare card, drug plan card, medication list with doses, the hematologist’s contact info, and the written pain plan. Keep a paper copy and photos on your phone.',
        why: 'When pain hits, nobody should be searching for a plan ID number.',
      },
      {
        id: 'c-refill',
        title: 'Set refill reminders before medicine runs low',
        detail:
          'Ask the pharmacy about automatic refills or 90-day supplies for long-term medicines, and note when controlled pain medicines can be refilled.',
        why: 'Running out is a common path to avoidable ER visits.',
      },
      {
        id: 'c-rep',
        title: 'Become an authorized representative',
        detail:
          'With permission, the person you care for can name you on file with Medicare (1-800-MEDICARE) and the drug plan so you can call on their behalf.',
        why: 'Plans can only discuss coverage with people who are authorized.',
      },
      {
        id: 'c-enroll',
        title: 'Mark Open Enrollment on the calendar',
        detail:
          'Each year from October 15 to December 7, review the drug plan. Formularies and costs change every January.',
        why: 'A plan that worked last year may not cover the same medicines this year.',
      },
      {
        id: 'c-cost',
        title: 'Spread out costs with the Medicare Prescription Payment Plan',
        detail:
          'Drug plans let members pay out-of-pocket costs in monthly installments instead of all at the pharmacy. Yearly out-of-pocket drug costs are now capped.',
        why: 'Big up-front copays cause people to leave prescriptions at the counter.',
      },
    ],
  },
  {
    id: 'clinician',
    label: 'I’m a clinician or pharmacist',
    short: 'Clinician',
    intro:
      'Small steps on your notes can help a patient get pain medicine through Medicare.',
    steps: [
      {
        id: 'k-code',
        title: 'Add the sickle cell code',
        detail:
          'Write the ICD-10 code D57 on each pain prescription. It tells the drug plan the patient has sickle cell. Then the plan can skip some of its Part D opioid limits.',
        why: 'Claims get denied when the code is missing.',
      },
      {
        id: 'k-plan',
        title: 'Make a pain plan',
        detail:
          'Write a pain plan for each patient. Use the national care guides. Share the plan with the patient, the pharmacy, and the local ER.',
        why: 'A clear plan means less waiting and fairer care.',
      },
      {
        id: 'k-screen',
        title: 'Ask about coverage',
        detail:
          'At each visit, ask if the patient has a drug plan. Ask if it was hard to pick up the last prescription. If it was, send them to SHIP or a social worker.',
        why: 'Many patients will not tell you they went without.',
      },
      {
        id: 'k-pa',
        title: 'Send prior authorizations fast',
        detail:
          'Some plans need prior authorization, which means they approve a drug before they pay. Send that request the same day. Ask for a fast decision, since the patient is in pain.',
        why: 'Plans must answer fast requests in 24 hours.',
      },
      {
        id: 'k-pharm',
        title: 'Pharmacists: fix denied claims',
        detail:
          'Check if the sickle cell exemption applies. If the code is missing, call the prescriber and ask for it. Stock common pain medicines if you can.',
        why: 'The pharmacy counter is where coverage turns into medicine.',
      },
    ],
  },
  {
    id: 'community',
    label: 'I want to help my community',
    short: 'Community',
    intro:
      'Churches, barbershops, schools, and neighbors reach people that clinics never see. Here is how to put this knowledge to work.',
    steps: [
      {
        id: 'm-share',
        title: 'Share this site with three people',
        detail:
          'Send it to a family group chat, post it on social media, or print the QR flyer for a community board.',
        why: 'Most people learn about Medicare help from someone they trust.',
      },
      {
        id: 'm-host',
        title: 'Host a Medicare help session',
        detail:
          'Invite a SHIP counselor or local sickle cell organization to your church, library, or community center during Open Enrollment.',
        why: 'Group sessions reach many families at once.',
        link: { label: 'Find a sickle cell organization', href: 'https://www.sicklecelldisease.org' },
      },
      {
        id: 'm-trait',
        title: 'Know your own trait status',
        detail:
          'About 1 in 13 Black or African American babies is born with sickle cell trait. Ask your doctor for a simple blood test if you do not know your status.',
        why: 'Knowing your status helps your family plan and understand.',
      },
      {
        id: 'm-stigma',
        title: 'Speak up against pain stigma',
        detail:
          'People with sickle cell are too often treated as “drug seeking.” Believe patients when they describe their pain and say so when you hear stigma.',
        why: 'Stigma keeps people from asking for the medication they need.',
      },
      {
        id: 'm-give',
        title: 'Give blood',
        detail:
          'Many people with sickle cell need regular transfusions, and closely matched blood often comes from donors of the same ethnic background.',
        why: 'A steady, diverse blood supply saves lives during crises.',
      },
    ],
  },
]

export const myths = [
  {
    statement: 'Sickle cell disease is contagious.',
    truth: false,
    explain:
      'You cannot catch sickle cell. It is inherited — a person is born with it when they get a sickle gene from each parent.',
  },
  {
    statement: 'Only Black people get sickle cell disease.',
    truth: false,
    explain:
      'It is most common in people with African ancestry, but it also affects people with Hispanic, Middle Eastern, South Asian, and Mediterranean heritage.',
  },
  {
    statement: 'Adults under 65 with sickle cell can qualify for Medicare.',
    truth: true,
    explain:
      'People who receive Social Security Disability benefits for 24 months become eligible for Medicare, regardless of age.',
  },
  {
    statement: 'Asking for pain medication means a patient is addicted.',
    truth: false,
    explain:
      'Sickle cell pain is real, severe, and caused by blocked blood flow. Rates of addiction are not higher than in the general population.',
  },
  {
    statement: 'Medicare Part A and B cover the pain pills I pick up at the pharmacy.',
    truth: false,
    explain:
      'Pharmacy prescriptions are covered by Part D or a Medicare Advantage plan with drug coverage — not Original Medicare alone.',
  },
]

export const resources = [
  { name: '1-800-MEDICARE', detail: '1-800-633-4227 · TTY 1-877-486-2048 · 24/7', href: 'tel:18006334227' },
  { name: 'Medicare Plan Finder', detail: 'Compare drug plans by your exact medicines', href: 'https://www.medicare.gov/plan-compare' },
  { name: 'Extra Help (Social Security)', detail: 'Lower drug costs if you have limited income', href: 'https://www.ssa.gov/extrahelp' },
  { name: 'SHIP counseling', detail: 'Free, unbiased Medicare help in your state', href: 'https://www.shiphelp.org' },
  { name: 'Sickle Cell Disease Association of America', detail: 'Local chapters, support groups, advocacy', href: 'https://www.sicklecelldisease.org' },
  { name: 'CDC: Sickle Cell Disease', detail: 'Facts, data, and living-well guides', href: 'https://www.cdc.gov/sickle-cell' },
  { name: 'Mayo Clinic: Treatment options', detail: 'Plain-language overview of sickle cell treatments', href: 'https://mcpress.mayoclinic.org/living-well/treatment-options-for-sickle-cell-disease' },
  { name: 'Live Unlimited', detail: 'Stories, tips, and support for living with sickle cell', href: 'https://www.liveunlimited.com' },
  { name: 'SC DPH: Sickle cell program', detail: 'South Carolina support for children and youth with sickle cell', href: 'https://dph.sc.gov/health-wellness/child-teen-health/children-and-youth-special-health-care-needs-cyshcn/sickle-cell' },
  { name: 'Medicaid.gov: Improving sickle cell care', detail: 'Quality-of-care efforts and resources for state programs', href: 'https://www.medicaid.gov/medicaid/quality-of-care/quality-improvement/improving-care-for-sickle-cell-disease' },
  { name: 'NHLBI: Sickle cell research', detail: 'NIH research, clinical trials, and new treatments', href: 'https://www.nhlbi.nih.gov/research/sickle-cell-disease' },
  { name: 'American Red Cross Blood Services', detail: 'Give blood — many patients rely on transfusions', href: 'https://www.redcrossblood.org' },
]
