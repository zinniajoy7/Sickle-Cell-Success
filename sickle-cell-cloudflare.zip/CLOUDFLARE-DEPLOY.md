# Deploy on Cloudflare Pages
Build command: pnpm build
Build output directory: dist/client
Environment variable: NODE_VERSION = 22
